# GP-Tc CIF-to-GP Pipeline

This repository predicts superconductivity properties from crystal structures using graphlet histogram features, symmetry descriptors, and Gaussian Process (GP) models.

The intended workflow is:

1. Build features from CIF files.
2. Build training pickles from those features and a metadata CSV.
3. Train the GP regression and classification models.
4. Run inference on new CIF files.

## 1. Install

Use Python 3.8+ with CUDA-capable PyTorch for GP training.

```bash
pip install -r requirements.txt
```

The training scripts are configured for GPU use. Feature generation can run before training, but GP model training expects CUDA.

## 2. Prepare Inputs

Put CIF files here:

```text
data/ICSD/CIFS/
```

Create a metadata CSV here:

```text
data/metadata.csv
```

Required columns:

| Column | Meaning |
|--------|---------|
| `cif` | CIF filename, or any path whose basename matches a CIF in `data/ICSD/CIFS/` |
| `label` | `1` for superconductor, `0` for non-superconductor |
| `Tc` | Critical temperature used for regression training |

Optional columns used when present: `formula`, `train_test_label`.

Example:

```csv
cif,formula,label,Tc,train_test_label
material_001.cif,YBa2Cu3O7,1,92,train
material_002.cif,Cu,0,0,train
```

## 3. Build Features From CIF Files

Run the feature maker in CIF mode:

```bash
cd GP-Tc-main
MODE=CIF \
CIF_DIR="$PWD/data/ICSD/CIFS" \
OUT_ROOT="$PWD/data/generated/features" \
python main/Feature_Maker.py
```

This creates:

```text
data/generated/features/Graphlet_Data/
data/generated/features/Histogram_Features/
data/generated/features/manifest_cif.pkl
data/generated/features/conversion_report_cif.json
```

The histogram feature files are the inputs used to build the GP training datasets.

## 4. Build Training Pickles

Convert the metadata CSV plus generated histogram files into regression and classification training pickles:

```bash
python scripts/build_subset_training_pickles.py \
  --subset-csv data/metadata.csv \
  --hist-dir data/generated/features/Histogram_Features \
  --out-dir data/generated/pkls \
  --classification-out-name classification_data_from_cifs.pkl \
  --regression-out-name regression_data_from_cifs.pkl
```

This creates:

```text
data/generated/pkls/classification_data_from_cifs.pkl
data/generated/pkls/regression_data_from_cifs.pkl
```

## 5. Train GP Models

The default model locations match the inference script:

```text
src/GP_Models/Trained Models/Classifier_2odr_all-sym/
src/GP_Models/Trained Models/Regressor_4-2odr_all-sym/
```

Train regression:

```bash
cd src/GP_Models/sc_train_gp-main/scripts

python general_example_gp_regression.py \
  --save_data_dir "../../Trained Models/Regressor_4-2odr_all-sym" \
  --path_to_data_file "../../../data/generated/pkls/regression_data_from_cifs.pkl" \
  --hist_features_key "histogram_features" \
  --labels_key "Tc" \
  --symm_features_key "symmetry_features" \
  --list_of_hist_features_to_use 13 18 26 30 \
  --list_of_symm_features_to_use 0 1 2 3 4 5 6 7 8 9 10 \
  --n_epochs 32
```

Train classification:

```bash
python general_example_gp_classification.py \
  --save_data_dir "../../Trained Models/Classifier_2odr_all-sym" \
  --path_to_data_file "../../../data/generated/pkls/classification_data_from_cifs.pkl" \
  --hist_features_key "X_all" \
  --labels_key "label" \
  --symm_features_key "symm_features" \
  --list_of_hist_features_to_use 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 \
  --list_of_symm_features_to_use 0 1 2 3 4 5 6 7 8 9 10 \
  --n_epochs 32 \
  --use_oversampling True
```

## 6. One-Command Training Path

To run feature generation, training-pickle creation, and both GP training jobs with the defaults above:

```bash
cd GP-Tc-main
bash scripts/run_from_scratch.sh
```

Useful overrides:

```bash
DATA_CSV=/path/to/metadata.csv \
CIF_DIR=/path/to/cifs \
PYTHON_BIN=/path/to/python \
EPOCHS=32 \
bash scripts/run_from_scratch.sh
```

## 7. Inference

After training, run prediction on a single CIF:

```bash
cd GP-Tc-main/src
python predict_single_cif.py /path/to/new_structure.cif
```

JSON output:

```bash
python predict_single_cif.py /path/to/new_structure.cif --json
```

By default, inference loads:

```text
../data/generated/pkls/classification_data_from_cifs.pkl
../data/generated/pkls/regression_data_from_cifs.pkl
GP_Models/Trained Models/Classifier_2odr_all-sym/
GP_Models/Trained Models/Regressor_4-2odr_all-sym/
```

Use explicit paths if you trained elsewhere:

```bash
python predict_single_cif.py /path/to/new_structure.cif \
  --class-training-data ../data/generated/pkls/classification_data_from_cifs.pkl \
  --reg-training-data ../data/generated/pkls/regression_data_from_cifs.pkl \
  --class-model-dir "GP_Models/Trained Models/Classifier_2odr_all-sym" \
  --reg-model-dir "GP_Models/Trained Models/Regressor_4-2odr_all-sym"
```

The prediction output includes:

- Classification probability that the material is superconducting.
- Classification uncertainty.
- Regression prediction for `Tc`.
- Regression uncertainty.

## Repository Layout

```text
config/                         Fixed feature/bin/symmetry configuration
data/                           Input CIFs, metadata CSV, generated artifacts
main/Feature_Maker.py           CIF-to-feature generation
scripts/run_from_scratch.sh     End-to-end feature build and training driver
scripts/build_subset_training_pickles.py
src/predict_single_cif.py       Single-CIF inference
src/GP_Models/                  GP training and prediction modules
FEATURE_INDEX_MAPPING.md        Graphlet and symmetry feature index reference
```

## Notes

- Keep the same feature indices for training and inference unless you also update the prediction code.
- Regression uses histogram indices `13 18 26 30` and all 11 symmetry features.
- Classification uses the 21 second-order histogram channels and all 11 symmetry features.
- Generated data, model checkpoints, logs, and CIF files are ignored by `.gitignore`.
