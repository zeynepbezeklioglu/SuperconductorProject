# Data Inputs

Place fresh inputs here before running the pipeline:

- `metadata.csv`: one row per material, with required columns `cif`, `label`, and `Tc`.
- `ICSD/CIFS/`: CIF files referenced by the `cif` column.

Generated features and training pickles are written to `data/generated/` by `scripts/run_from_scratch.sh`.
