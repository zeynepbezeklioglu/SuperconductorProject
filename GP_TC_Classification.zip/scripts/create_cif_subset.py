#!/usr/bin/env python3
import argparse
import csv
import json
import random
import shutil
from pathlib import Path


def _resolve_path(base_root: Path, cif_value: str) -> Path:
    p = Path(cif_value)
    if p.is_absolute():
        return p
    return base_root / p


def _sample_rows(rows, n, seed):
    if len(rows) < n:
        raise ValueError(f"Requested {n} rows but only {len(rows)} available")
    rng = random.Random(seed)
    idx = list(range(len(rows)))
    rng.shuffle(idx)
    return [rows[i] for i in idx[:n]]


def _place_file(src: Path, dst: Path, mode: str) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists() or dst.is_symlink():
        dst.unlink()
    if mode == "copy":
        shutil.copy2(src, dst)
    elif mode == "symlink":
        dst.symlink_to(src)
    else:
        raise ValueError(f"Unknown mode: {mode}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Create fixed-size CIF subset from CSV train/test labels")
    parser.add_argument("--input-csv", type=Path, required=True)
    parser.add_argument("--base-root", type=Path, required=True, help="Root used to resolve relative CIF paths")
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--n-train", type=int, default=350)
    parser.add_argument("--n-test", type=int, default=150)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--mode", choices=["symlink", "copy"], default="symlink")
    args = parser.parse_args()

    out_dir = args.out_dir
    cifs_train = out_dir / "cifs" / "train"
    cifs_test = out_dir / "cifs" / "test"
    cifs_all = out_dir / "cifs" / "all"
    out_dir.mkdir(parents=True, exist_ok=True)
    cifs_train.mkdir(parents=True, exist_ok=True)
    cifs_test.mkdir(parents=True, exist_ok=True)
    cifs_all.mkdir(parents=True, exist_ok=True)

    with args.input_csv.open("r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames
        if not fieldnames:
            raise RuntimeError("Input CSV missing header")
        rows = list(reader)

    train_rows = [r for r in rows if (r.get("train_test_label") or "").strip().lower() == "train"]
    test_rows = [r for r in rows if (r.get("train_test_label") or "").strip().lower() == "test"]

    selected_train = _sample_rows(train_rows, args.n_train, args.seed)
    selected_test = _sample_rows(test_rows, args.n_test, args.seed + 1)

    selected = []
    seen_names = set()

    def add_rows(part_rows, split_name, split_dir):
        nonlocal selected, seen_names
        for r in part_rows:
            src = _resolve_path(args.base_root, r["cif"]).resolve()
            if not src.exists():
                raise FileNotFoundError(f"CIF not found: {src}")

            stem = src.stem
            suffix = src.suffix
            candidate_name = src.name
            i = 1
            while candidate_name in seen_names:
                candidate_name = f"{stem}__dup{i}{suffix}"
                i += 1
            seen_names.add(candidate_name)

            dst_split = split_dir / candidate_name
            dst_all = cifs_all / candidate_name
            _place_file(src, dst_split, args.mode)
            _place_file(src, dst_all, args.mode)

            row = dict(r)
            row["subset_split"] = split_name
            row["subset_cif_name"] = candidate_name
            row["subset_cif_relpath"] = f"cifs/{split_name}/{candidate_name}"
            selected.append(row)

    add_rows(selected_train, "train", cifs_train)
    add_rows(selected_test, "test", cifs_test)

    out_csv = out_dir / "subset_metadata.csv"
    out_fields = list(fieldnames) + ["subset_split", "subset_cif_name", "subset_cif_relpath"]
    with out_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=out_fields)
        writer.writeheader()
        writer.writerows(selected)

    summary = {
        "input_csv": str(args.input_csv),
        "base_root": str(args.base_root),
        "seed": args.seed,
        "mode": args.mode,
        "requested": {"train": args.n_train, "test": args.n_test},
        "created": {"train": len(selected_train), "test": len(selected_test), "total": len(selected)},
        "output_metadata_csv": str(out_csv),
        "cif_dirs": {
            "train": str(cifs_train),
            "test": str(cifs_test),
            "all": str(cifs_all),
        },
    }
    (out_dir / "subset_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
