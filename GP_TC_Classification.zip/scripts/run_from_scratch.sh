#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

PYTHON_BIN="${PYTHON_BIN:-python3}"

# Metadata CSV requirements:
# - cif: CIF filename or path. The basename must match a CIF file in CIF_DIR.
# - label: 1 for superconductor, 0 for non-superconductor.
# - Tc: critical temperature for regression rows.
# Optional but useful: formula, train_test_label.
DATA_CSV="${DATA_CSV:-${PROJECT_ROOT}/data/metadata.csv}"
CIF_DIR="${CIF_DIR:-${PROJECT_ROOT}/data/ICSD/CIFS}"

FEATURE_OUT="${FEATURE_OUT:-${PROJECT_ROOT}/data/generated/features}"
PKL_OUT="${PKL_OUT:-${PROJECT_ROOT}/data/generated/pkls}"

EPOCHS="${EPOCHS:-32}"
TEST_SET_SIZE="${TEST_SET_SIZE:-0.2}"
RANDOM_SPLIT_SEED="${RANDOM_SPLIT_SEED:-2}"
N_BATCHES_EMD_KERNEL="${N_BATCHES_EMD_KERNEL:-10}"

REG_LR="${REG_LR:-0.1}"
CLASS_LR="${CLASS_LR:-0.05}"
CLASS_MINI_BATCH="${CLASS_MINI_BATCH:-1024}"
CLASS_N_INDUCING="${CLASS_N_INDUCING:-1024}"
CLASS_USE_OVERSAMPLING="${CLASS_USE_OVERSAMPLING:-True}"

TRAIN_SCRIPTS_DIR="${PROJECT_ROOT}/src/GP_Models/sc_train_gp-main/scripts"
TRAINED_MODELS_DIR="${PROJECT_ROOT}/src/GP_Models/Trained Models"
REG_SAVE_DIR="${REG_SAVE_DIR:-${TRAINED_MODELS_DIR}/Regressor_4-2odr_all-sym}"
CLASS_SAVE_DIR="${CLASS_SAVE_DIR:-${TRAINED_MODELS_DIR}/Classifier_2odr_all-sym}"

REG_DATA="${PKL_OUT}/regression_data_from_cifs.pkl"
CLASS_DATA="${PKL_OUT}/classification_data_from_cifs.pkl"

REG_HIST_IDXS=(13 18 26 30)
SYM_IDXS=(0 1 2 3 4 5 6 7 8 9 10)
CLASS_HIST_IDXS=(0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20)

echo "=========================================="
echo "GP-Tc run from scratch"
echo "=========================================="
echo "Project root: ${PROJECT_ROOT}"
echo "Python: ${PYTHON_BIN}"
echo "Metadata CSV: ${DATA_CSV}"
echo "CIF directory: ${CIF_DIR}"
echo "Feature output: ${FEATURE_OUT}"
echo "Training pickle output: ${PKL_OUT}"
echo "=========================================="

if [[ ! -f "${DATA_CSV}" ]]; then
  echo "ERROR: DATA_CSV not found: ${DATA_CSV}" >&2
  exit 1
fi

if [[ ! -d "${CIF_DIR}" ]]; then
  echo "ERROR: CIF_DIR not found: ${CIF_DIR}" >&2
  exit 1
fi

"${PYTHON_BIN}" - <<'PYCHK'
import sys
import torch
if not torch.cuda.is_available():
    print("ERROR: CUDA is not available. GP training is configured as GPU-only.")
    sys.exit(2)
major, minor = torch.cuda.get_device_capability(0)
print(f"Using GPU: {torch.cuda.get_device_name(0)} | capability=sm_{major}{minor}", flush=True)
if major < 7:
    print("ERROR: GPU capability < sm_70 is unsupported for this environment.", flush=True)
    sys.exit(3)
PYCHK

echo "[1/4] Generating histogram and graphlet features from CIF files..."
mkdir -p "${FEATURE_OUT}"
(
  cd "${PROJECT_ROOT}/main"
  MODE="CIF" CIF_DIR="${CIF_DIR}" OUT_ROOT="${FEATURE_OUT}" \
    "${PYTHON_BIN}" -u Feature_Maker.py
)

echo "[2/4] Building training pickles from metadata and generated histograms..."
mkdir -p "${PKL_OUT}"
"${PYTHON_BIN}" -u "${PROJECT_ROOT}/scripts/build_subset_training_pickles.py" \
  --subset-csv "${DATA_CSV}" \
  --hist-dir "${FEATURE_OUT}/Histogram_Features" \
  --out-dir "${PKL_OUT}" \
  --classification-out-name "$(basename "${CLASS_DATA}")" \
  --regression-out-name "$(basename "${REG_DATA}")"

echo "[3/4] Training regression GP..."
mkdir -p "${REG_SAVE_DIR}"
(
  cd "${TRAIN_SCRIPTS_DIR}"
  "${PYTHON_BIN}" -u general_example_gp_regression.py \
    --save_data_dir "${REG_SAVE_DIR}" \
    --path_to_data_file "${REG_DATA}" \
    --hist_features_key "histogram_features" \
    --labels_key "Tc" \
    --symm_features_key "symmetry_features" \
    --list_of_hist_features_to_use "${REG_HIST_IDXS[@]}" \
    --list_of_symm_features_to_use "${SYM_IDXS[@]}" \
    --random_split_seed "${RANDOM_SPLIT_SEED}" \
    --test_set_size "${TEST_SET_SIZE}" \
    --n_epochs "${EPOCHS}" \
    --n_batches_emd_kernel "${N_BATCHES_EMD_KERNEL}" \
    --lr "${REG_LR}"
)

echo "[4/4] Training classification GP..."
mkdir -p "${CLASS_SAVE_DIR}"
(
  cd "${TRAIN_SCRIPTS_DIR}"
  "${PYTHON_BIN}" -u general_example_gp_classification.py \
    --save_data_dir "${CLASS_SAVE_DIR}" \
    --path_to_data_file "${CLASS_DATA}" \
    --hist_features_key "X_all" \
    --labels_key "label" \
    --symm_features_key "symm_features" \
    --list_of_hist_features_to_use "${CLASS_HIST_IDXS[@]}" \
    --list_of_symm_features_to_use "${SYM_IDXS[@]}" \
    --random_split_seed "${RANDOM_SPLIT_SEED}" \
    --test_set_size "${TEST_SET_SIZE}" \
    --n_epochs "${EPOCHS}" \
    --n_batches_emd_kernel "${N_BATCHES_EMD_KERNEL}" \
    --lr "${CLASS_LR}" \
    --n_inducing_pts "${CLASS_N_INDUCING}" \
    --use_oversampling "${CLASS_USE_OVERSAMPLING}" \
    --mini_batch_size "${CLASS_MINI_BATCH}"
)

echo "=========================================="
echo "Run complete"
echo "Regression model: ${REG_SAVE_DIR}"
echo "Classification model: ${CLASS_SAVE_DIR}"
echo "=========================================="
