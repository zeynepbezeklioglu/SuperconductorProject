#!/usr/bin/env python3
import argparse
import csv
import json
from pathlib import Path
from collections import Counter


def main() -> None:
    parser = argparse.ArgumentParser(description="Create deterministic train/test/unlabeled CSV splits from a metadata CSV")
    parser.add_argument("--input-csv", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()

    in_csv = args.input_csv
    out_dir = args.out_dir
    out_dir.mkdir(parents=True, exist_ok=True)

    with in_csv.open("r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames
        if not fieldnames:
            raise RuntimeError("Input CSV has no header")
        rows = list(reader)

    buckets = {"train": [], "test": [], "unlabeled": [], "other": []}
    for row in rows:
        split = (row.get("train_test_label") or "").strip().lower()
        if split in ("train", "test", "unlabeled"):
            buckets[split].append(row)
        elif split == "":
            # normalize blanks to unlabeled
            row = dict(row)
            row["train_test_label"] = "unlabeled"
            buckets["unlabeled"].append(row)
        else:
            buckets["other"].append(row)

    # Write canonical split files
    for split in ("train", "test", "unlabeled"):
        out_csv = out_dir / f"{split}.csv"
        with out_csv.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(buckets[split])

    # Optional: unknown labels bucket
    if buckets["other"]:
        out_csv = out_dir / "other.csv"
        with out_csv.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(buckets["other"])

    counts = {k: len(v) for k, v in buckets.items()}
    summary = {
        "input_csv": str(in_csv),
        "total_rows": len(rows),
        "split_counts": counts,
        "written_files": [
            str(out_dir / "train.csv"),
            str(out_dir / "test.csv"),
            str(out_dir / "unlabeled.csv"),
        ] + ([str(out_dir / "other.csv")] if buckets["other"] else []),
    }

    (out_dir / "split_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print("Split generation complete")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
