#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

PYTHON_BIN="${PYTHON_BIN:-python3}"
RUN_FEATURE_MAKER="${RUN_FEATURE_MAKER:-0}"   # 1 to regenerate features, 0 to skip
MODE="${MODE:-PICKLE}"                        # PICKLE or CIF (used only if RUN_FEATURE_MAKER=1)
CIF_DIR="${CIF_DIR:-${PROJECT_ROOT}/data/ICSD/CIFS}"
GRAPHLET_DIR="${GRAPHLET_DIR:-${PROJECT_ROOT}/data/Pickled_ICSD_Histograms}"
OUT_ROOT="${OUT_ROOT:-${PROJECT_ROOT}/ICSD_Features}"

EPOCHS="${EPOCHS:-32}"
TEST_SET_SIZE="${TEST_SET_SIZE:-0.2}"
RANDOM_SPLIT_SEED="${RANDOM_SPLIT_SEED:-2}"
N_BATCHES_EMD_KERNEL="${N_BATCHES_EMD_KERNEL:-10}"

REG_LR="${REG_LR:-0.1}"
CLASS_LR="${CLASS_LR:-0.05}"
CLASS_MINI_BATCH="${CLASS_MINI_BATCH:-1024}"
CLASS_N_INDUCING="${CLASS_N_INDUCING:-1024}"
CLASS_USE_OVERSAMPLING="${CLASS_USE_OVERSAMPLING:-True}"

REG_DATA="${REG_DATA:-${PROJECT_ROOT}/data/regression_data_histogram&symmetry.pkl}"
CLASS_DATA="${CLASS_DATA:-${PROJECT_ROOT}/data/classification_data_3DSCnonsc_labeled.pkl}"

TRAIN_SCRIPTS_DIR="${PROJECT_ROOT}/src/GP_Models/sc_train_gp-main/scripts"
TRAINED_MODELS_DIR="${PROJECT_ROOT}/src/GP_Models/Trained Models"
REG_SAVE_DIR="${REG_SAVE_DIR:-${TRAINED_MODELS_DIR}/Regressor_4-2odr_all-sym}"
CLASS_SAVE_DIR="${CLASS_SAVE_DIR:-${TRAINED_MODELS_DIR}/Classifier_2odr_all-sym}"

# Predictor compatibility:
# - Regression predictor expects hist indices [13,18,26,30] and all symmetry features (11).
# - Classification predictor expects 21 histogram channels and 11 symmetry channels.
REG_HIST_IDXS=(13 18 26 30)
SYM_IDXS=(0 1 2 3 4 5 6 7 8 9 10)
CLASS_HIST_IDXS=(0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20)

echo "=========================================="
echo "GP-Tc End-to-End Training"
echo "=========================================="
echo "Project root: ${PROJECT_ROOT}"
echo "Python: ${PYTHON_BIN}"
echo "Run feature maker: ${RUN_FEATURE_MAKER} (MODE=${MODE})"
echo "Regression data: ${REG_DATA}"
echo "Classification data: ${CLASS_DATA}"
echo "=========================================="

if [[ ! -x "${PYTHON_BIN}" ]]; then
  echo "ERROR: PYTHON_BIN not executable: ${PYTHON_BIN}" >&2
  exit 1
fi

# GPU-only guard: do not run on CPU-only allocations
"${PYTHON_BIN}" - <<'PYCHK'
import sys
import torch
if not torch.cuda.is_available():
    print('ERROR: CUDA is not available. This training pipeline is GPU-only (no CPU fallback).')
    sys.exit(2)
major, minor = torch.cuda.get_device_capability(0)
name = torch.cuda.get_device_name(0)
print(f'Using GPU: {name} | capability=sm_{major}{minor}', flush=True)
if major < 7:
    print('ERROR: GPU capability < sm_70 is unsupported for this environment.', flush=True)
    sys.exit(3)
PYCHK

if [[ "${RUN_FEATURE_MAKER}" == "1" ]]; then
  echo "[1/3] Running feature generation..."
  (
    cd "${PROJECT_ROOT}/main"
    MODE="${MODE}" CIF_DIR="${CIF_DIR}" GRAPHLET_DIR="${GRAPHLET_DIR}" OUT_ROOT="${OUT_ROOT}" \
      "${PYTHON_BIN}" -u Feature_Maker.py
  )
else
  echo "[1/3] Skipping feature generation (RUN_FEATURE_MAKER=0)"
fi

echo "[2/3] Training regression GP..."
mkdir -p "${REG_SAVE_DIR}"
(
  cd "${TRAIN_SCRIPTS_DIR}"
  "${PYTHON_BIN}" -u general_example_gp_regression.py \
    --save_data_dir "${REG_SAVE_DIR}" \
    --path_to_data_file "${REG_DATA}" \
    --hist_features_key "histogram_features" \
    --labels_key "Tc" \
    --symm_features_key "symmetry_features" \
    --list_of_hist_features_to_use "${REG_HIST_IDXS[@]}" \
    --list_of_symm_features_to_use "${SYM_IDXS[@]}" \
    --random_split_seed "${RANDOM_SPLIT_SEED}" \
    --test_set_size "${TEST_SET_SIZE}" \
    --n_epochs "${EPOCHS}" \
    --n_batches_emd_kernel "${N_BATCHES_EMD_KERNEL}" \
    --lr "${REG_LR}"
)

echo "[3/3] Training classification GP..."
mkdir -p "${CLASS_SAVE_DIR}"
(
  cd "${TRAIN_SCRIPTS_DIR}"
  "${PYTHON_BIN}" -u general_example_gp_classification.py \
    --save_data_dir "${CLASS_SAVE_DIR}" \
    --path_to_data_file "${CLASS_DATA}" \
    --hist_features_key "X_all" \
    --labels_key "label" \
    --symm_features_key "symm_features" \
    --list_of_hist_features_to_use "${CLASS_HIST_IDXS[@]}" \
    --list_of_symm_features_to_use "${SYM_IDXS[@]}" \
    --random_split_seed "${RANDOM_SPLIT_SEED}" \
    --test_set_size "${TEST_SET_SIZE}" \
    --n_epochs "${EPOCHS}" \
    --n_batches_emd_kernel "${N_BATCHES_EMD_KERNEL}" \
    --lr "${CLASS_LR}" \
    --n_inducing_pts "${CLASS_N_INDUCING}" \
    --use_oversampling "${CLASS_USE_OVERSAMPLING}" \
    --mini_batch_size "${CLASS_MINI_BATCH}"
)

echo "=========================================="
echo "Training complete"
echo "Regression outputs: ${REG_SAVE_DIR}"
echo "Classification outputs: ${CLASS_SAVE_DIR}"
echo "=========================================="
