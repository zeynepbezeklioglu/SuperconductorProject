#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

PYTHON_BIN="${PYTHON_BIN:-python3}"
SUBSET_DIR="${SUBSET_DIR:-${PROJECT_ROOT}/data/cif_subset_500}"
INPUT_CSV="${INPUT_CSV:-${PROJECT_ROOT}/data/metadata.csv}"
BASE_ROOT="${BASE_ROOT:-${PROJECT_ROOT}}"
N_TRAIN="${N_TRAIN:-350}"
N_TEST="${N_TEST:-150}"
SUBSET_SEED="${SUBSET_SEED:-42}"
SUBSET_MODE="${SUBSET_MODE:-symlink}"   # symlink or copy

FEATURE_OUT="${FEATURE_OUT:-${SUBSET_DIR}/features}"
PKL_OUT="${PKL_OUT:-${SUBSET_DIR}/pkls}"
FEATURE_MAKER_CHUNK_SIZE="${FEATURE_MAKER_CHUNK_SIZE:-50}"

EPOCHS="${EPOCHS:-32}"
TEST_SET_SIZE="${TEST_SET_SIZE:-0.2}"
RANDOM_SPLIT_SEED="${RANDOM_SPLIT_SEED:-2}"
N_BATCHES_EMD_KERNEL="${N_BATCHES_EMD_KERNEL:-10}"
REG_LR="${REG_LR:-0.1}"
CLASS_LR="${CLASS_LR:-0.05}"
CLASS_MINI_BATCH="${CLASS_MINI_BATCH:-512}"
CLASS_N_INDUCING="${CLASS_N_INDUCING:-256}"
CLASS_USE_OVERSAMPLING="${CLASS_USE_OVERSAMPLING:-True}"

TRAIN_SCRIPTS_DIR="${PROJECT_ROOT}/src/GP_Models/sc_train_gp-main/scripts"
TRAINED_MODELS_DIR="${PROJECT_ROOT}/src/GP_Models/Trained Models"
REG_SAVE_DIR="${REG_SAVE_DIR:-${TRAINED_MODELS_DIR}/Regressor_subset500_cif}"
CLASS_SAVE_DIR="${CLASS_SAVE_DIR:-${TRAINED_MODELS_DIR}/Classifier_subset500_cif}"

REG_DATA="${PKL_OUT}/regression_subset_500.pkl"
CLASS_DATA="${PKL_OUT}/classification_subset_500.pkl"

REG_HIST_IDXS=(13 18 26 30)
SYM_IDXS=(0 1 2 3 4 5 6 7 8 9 10)
CLASS_HIST_IDXS=(0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20)

echo "=========================================="
echo "GP-Tc CIF Subset (500) Training"
echo "=========================================="
echo "Project root: ${PROJECT_ROOT}"
echo "Subset dir: ${SUBSET_DIR}"
echo "Python: ${PYTHON_BIN}"
echo "Subset mode: ${SUBSET_MODE}"
echo "Feature_Maker chunk size: ${FEATURE_MAKER_CHUNK_SIZE}"
echo "=========================================="

if [[ ! -x "${PYTHON_BIN}" ]]; then
  echo "ERROR: PYTHON_BIN not executable: ${PYTHON_BIN}" >&2
  exit 1
fi

# GPU-only guard (no CPU fallback)
"${PYTHON_BIN}" - <<'PYCHK'
import sys
import torch
if not torch.cuda.is_available():
    print('ERROR: CUDA is not available. This pipeline is GPU-only.')
    sys.exit(2)
major, minor = torch.cuda.get_device_capability(0)
name = torch.cuda.get_device_name(0)
print(f'Using GPU: {name} | capability=sm_{major}{minor}', flush=True)
if major < 7:
    print('ERROR: GPU capability < sm_70 is unsupported for this environment.', flush=True)
    sys.exit(3)
PYCHK

echo "[1/5] Creating 350/150 CIF subset from CSV..."
"${PYTHON_BIN}" -u "${PROJECT_ROOT}/scripts/create_cif_subset.py" \
  --input-csv "${INPUT_CSV}" \
  --base-root "${BASE_ROOT}" \
  --out-dir "${SUBSET_DIR}" \
  --n-train "${N_TRAIN}" \
  --n-test "${N_TEST}" \
  --seed "${SUBSET_SEED}" \
  --mode "${SUBSET_MODE}"

echo "[2/5] Running Feature_Maker in CIF mode on subset/all..."
mkdir -p "${FEATURE_OUT}"
conv_t0=$(date +%s)
(
  cd "${PROJECT_ROOT}/main"
  MODE="CIF" CIF_DIR="${SUBSET_DIR}/cifs/all" OUT_ROOT="${FEATURE_OUT}" \
  FEATURE_MAKER_CHUNK_SIZE="${FEATURE_MAKER_CHUNK_SIZE}" \
    "${PYTHON_BIN}" -u Feature_Maker.py
)
conv_t1=$(date +%s)
conv_dt=$((conv_t1-conv_t0))
echo "[2/5] CIF->hist conversion finished in ${conv_dt}s"
echo "[2/5] Conversion report: ${FEATURE_OUT}/conversion_report_cif.json"

echo "[3/5] Building subset training PKLs..."
mkdir -p "${PKL_OUT}"
"${PYTHON_BIN}" -u "${PROJECT_ROOT}/scripts/build_subset_training_pickles.py" \
  --subset-csv "${SUBSET_DIR}/subset_metadata.csv" \
  --hist-dir "${FEATURE_OUT}/Histogram_Features" \
  --out-dir "${PKL_OUT}"

echo "[4/5] Training regression GP on subset..."
mkdir -p "${REG_SAVE_DIR}"
(
  cd "${TRAIN_SCRIPTS_DIR}"
  "${PYTHON_BIN}" -u general_example_gp_regression.py \
    --save_data_dir "${REG_SAVE_DIR}" \
    --path_to_data_file "${REG_DATA}" \
    --hist_features_key "histogram_features" \
    --labels_key "Tc" \
    --symm_features_key "symmetry_features" \
    --list_of_hist_features_to_use "${REG_HIST_IDXS[@]}" \
    --list_of_symm_features_to_use "${SYM_IDXS[@]}" \
    --random_split_seed "${RANDOM_SPLIT_SEED}" \
    --test_set_size "${TEST_SET_SIZE}" \
    --n_epochs "${EPOCHS}" \
    --n_batches_emd_kernel "${N_BATCHES_EMD_KERNEL}" \
    --lr "${REG_LR}"
)

echo "[5/5] Training classification GP on subset..."
mkdir -p "${CLASS_SAVE_DIR}"
(
  cd "${TRAIN_SCRIPTS_DIR}"
  "${PYTHON_BIN}" -u general_example_gp_classification.py \
    --save_data_dir "${CLASS_SAVE_DIR}" \
    --path_to_data_file "${CLASS_DATA}" \
    --hist_features_key "X_all" \
    --labels_key "label" \
    --symm_features_key "symm_features" \
    --list_of_hist_features_to_use "${CLASS_HIST_IDXS[@]}" \
    --list_of_symm_features_to_use "${SYM_IDXS[@]}" \
    --random_split_seed "${RANDOM_SPLIT_SEED}" \
    --test_set_size "${TEST_SET_SIZE}" \
    --n_epochs "${EPOCHS}" \
    --n_batches_emd_kernel "${N_BATCHES_EMD_KERNEL}" \
    --lr "${CLASS_LR}" \
    --n_inducing_pts "${CLASS_N_INDUCING}" \
    --use_oversampling "${CLASS_USE_OVERSAMPLING}" \
    --mini_batch_size "${CLASS_MINI_BATCH}"
)

echo "=========================================="
echo "Subset CIF training complete"
echo "Subset metadata: ${SUBSET_DIR}/subset_metadata.csv"
echo "Feature output: ${FEATURE_OUT}"
echo "Subset PKLs: ${PKL_OUT}"
echo "Reg model: ${REG_SAVE_DIR}"
echo "Class model: ${CLASS_SAVE_DIR}"
echo "=========================================="
