#!/usr/bin/env python3
import argparse
import csv
import json
import pickle
from pathlib import Path

import numpy as np


def _to_float(x):
    try:
        return float(x)
    except Exception:
        return None


def _to_int(x):
    try:
        return int(float(x))
    except Exception:
        return None


def _load_hist_payload(hist_dir: Path, cif_name: str):
    stem = Path(cif_name).stem
    hp = hist_dir / f"{stem}_histogram.pkl"
    if not hp.exists():
        return None, hp
    with hp.open("rb") as f:
        return pickle.load(f), hp


def _squeeze_hist(arr):
    a = np.asarray(arr)
    if a.ndim == 4 and a.shape[0] == 1:
        return a[0]
    if a.ndim == 3:
        return a
    raise ValueError(f"Unexpected histogram shape: {a.shape}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Build regression/classification training pickles from metadata + histogram files")
    parser.add_argument("--subset-csv", type=Path, required=True)
    parser.add_argument("--hist-dir", type=Path, required=True, help="Directory containing *_histogram.pkl files")
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--classification-out-name", default="classification_subset_500.pkl")
    parser.add_argument("--regression-out-name", default="regression_subset_500.pkl")
    args = parser.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)

    with args.subset_csv.open("r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    # Classification containers
    cls_X, cls_y, cls_S = [], [], []
    cls_cif, cls_formula, cls_split = [], [], []

    # Regression containers
    reg_X, reg_y, reg_S = [], [], []
    reg_formula, reg_class, reg_cif, reg_split = [], [], [], []

    hist_feat_names = None
    symm_feat_names = None

    missing_hist = []
    bad_label = 0
    bad_tc = 0

    for row in rows:
        cif_name = row.get("subset_cif_name") or Path(row.get("cif", "")).name
        payload, hist_path = _load_hist_payload(args.hist_dir, cif_name)
        if payload is None:
            missing_hist.append(str(hist_path))
            continue

        # Common features
        clas_hist = _squeeze_hist(payload["clas_histograms"])
        reg_hist = _squeeze_hist(payload["reg_histograms"])
        symm = np.asarray(payload["symmetry_feature"], dtype=np.float32)

        if hist_feat_names is None:
            hist_feat_names = payload.get("hist_feat_name")
        if symm_feat_names is None:
            symm_feat_names = payload.get("symmetry_feature_names")

        # Classification dataset
        y_lbl = _to_int(row.get("label"))
        if y_lbl is None:
            bad_label += 1
        else:
            # Keep the 2nd-order window used by existing classifier pipeline
            # (21 channels expected by downstream scripts)
            if clas_hist.shape[0] >= 31:
                x_cls = clas_hist[10:31, :, :]
            else:
                x_cls = clas_hist
            cls_X.append(np.asarray(x_cls, dtype=np.float32))
            cls_y.append(y_lbl)
            cls_S.append(symm)
            cls_cif.append(cif_name)
            cls_formula.append(row.get("formula") or payload.get("reduced_formula"))
            cls_split.append((row.get("subset_split") or row.get("train_test_label") or "").strip().lower())

        # Regression dataset
        tc = _to_float(row.get("Tc"))
        if tc is None:
            bad_tc += 1
        else:
            reg_X.append(np.asarray(reg_hist, dtype=np.float32))
            reg_y.append(float(tc))
            reg_S.append(symm)
            reg_formula.append(row.get("formula") or payload.get("reduced_formula"))
            reg_class.append(y_lbl if y_lbl is not None else -1)
            reg_cif.append(cif_name)
            reg_split.append((row.get("subset_split") or row.get("train_test_label") or "").strip().lower())

    class_dict = {
        "X_all": np.asarray(cls_X, dtype=np.float32),
        "label": np.asarray(cls_y, dtype=np.int64),
        "symm_features": np.asarray(cls_S, dtype=np.float32),
        "cif": cls_cif,
        "formula": cls_formula,
        "train_test_label": cls_split,
    }

    reg_dict = {
        "histogram_features": np.asarray(reg_X, dtype=np.float32),
        "Tc": np.asarray(reg_y, dtype=np.float32),
        "formula": reg_formula,
        "class": np.asarray(reg_class, dtype=np.int64),
        "histogram_feat_names": hist_feat_names,
        "symmetry_features": np.asarray(reg_S, dtype=np.float32),
        "symmetry_feature_names": symm_feat_names,
        "cif": reg_cif,
        "train_test_label": reg_split,
    }

    class_pkl = args.out_dir / args.classification_out_name
    reg_pkl = args.out_dir / args.regression_out_name

    with class_pkl.open("wb") as f:
        pickle.dump(class_dict, f, protocol=pickle.HIGHEST_PROTOCOL)
    with reg_pkl.open("wb") as f:
        pickle.dump(reg_dict, f, protocol=pickle.HIGHEST_PROTOCOL)

    summary = {
        "subset_csv": str(args.subset_csv),
        "hist_dir": str(args.hist_dir),
        "counts": {
            "rows_in_subset_csv": len(rows),
            "classification_rows": int(len(cls_X)),
            "regression_rows": int(len(reg_X)),
            "missing_hist_files": len(missing_hist),
            "bad_label_rows": bad_label,
            "bad_tc_rows": bad_tc,
        },
        "outputs": {
            "classification_pkl": str(class_pkl),
            "regression_pkl": str(reg_pkl),
        },
    }

    (args.out_dir / "build_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    if missing_hist:
        (args.out_dir / "missing_hist_files.txt").write_text("\n".join(missing_hist), encoding="utf-8")

    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
