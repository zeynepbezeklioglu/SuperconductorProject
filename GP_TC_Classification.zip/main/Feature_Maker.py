#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Feature Maker
=============

This script processes either:
- existing graphlet pickle files (MODE=PICKLE), or
- raw CIF files (MODE=CIF),

and generates split histogram/graphlet outputs.

Enhancements
------------
- Explicit chunk-level progress logging with ETA.
- End-to-end conversion timing summary.
- Writes a JSON conversion report in OUT_ROOT.

Author
------
Aaditya Panigrahi
"""

import json
import math
import os
import pickle
import re
import sys
import time
import traceback
import warnings

# --- Configuration & Path Setup ---
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(SCRIPT_DIR)  # Assumes script is in <root>/main
SRC_DIR = os.path.join(PROJECT_ROOT, "src")

if SRC_DIR not in sys.path:
    sys.path.append(SRC_DIR)

CIF_DIR = os.getenv("CIF_DIR", os.path.join(PROJECT_ROOT, "data", "ICSD", "CIFS"))
GRAPHLET_DIR = os.getenv("GRAPHLET_DIR", os.path.join(PROJECT_ROOT, "data", "Pickled_ICSD_Histograms"))
OUT_ROOT = os.getenv("OUT_ROOT", os.path.join(PROJECT_ROOT, "ICSD_Features"))
MODE = os.getenv("MODE", "PICKLE")  # Options: "PICKLE" (default), "CIF"

from SplitGraphletSymmetryProcessor import ICSDGraphletProcessor, load_bins_from_config  # noqa: E402
from ParallelRunner import ParallelRunner  # noqa: E402

warnings.filterwarnings("ignore")


def extract_icsd_id(filename: str) -> str:
    """
    Extract the ICSD ID (string) from filenames.
    Expects format ending in 'icsd_{id}.cif' or 'icsd_{id}' segments.
    """
    match = re.search(r"icsd_(\d+)\.cif$", filename)
    if match:
        return match.group(1)

    match = re.search(r"icsd_(\d+)", filename)
    if match:
        return match.group(1)

    raise ValueError(f"No ICSD ID found in '{filename}'")


def BuildFromGraphlet(graph_path, bin_clas, bin_reg, feat_names, out_root=OUT_ROOT):
    """
    For a single graphlet pickle:
      - Extract ICSD ID from filename
      - Load graphlet object
      - Load corresponding CIF
      - Recompute histograms & save split outputs
    """
    try:
        icsd_id = extract_icsd_id(os.path.basename(graph_path))
        cif_path = os.path.join(CIF_DIR, f"icsd_{icsd_id}.cif")

        with open(graph_path, "rb") as f:
            data = pickle.load(f)
        graphlet_inst = data.get("materials") or data.get("graphlet") or data
        if isinstance(graphlet_inst, list):
            graphlet_inst = graphlet_inst[0]

        proc = ICSDGraphletProcessor(
            cif_file=cif_path,
            graphlet=graphlet_inst,
            bin_centers_clas_2d=bin_clas,
            bin_centers_reg_2d=bin_reg,
            feature_names=feat_names,
        )
        if not getattr(proc, "ok", False):
            err = getattr(proc, "error", None)
            if err is None:
                raise RuntimeError("ICSDGraphletProcessor init failed (no error object).")
            raise RuntimeError(f"{type(err).__name__}: {err}") from err

        hist_path, gpath = proc.pickle_split_outputs(out_root=out_root)
        return {"graph_path": gpath, "hist_path": hist_path, "ok": True}

    except Exception as e:
        print(f"Failed for {graph_path}: {e}", flush=True)
        print(traceback.format_exc(limit=2), flush=True)
        return {"graph_path": graph_path, "error": str(e), "ok": False}


def BuildFromCIF(cif_path, bin_clas, bin_reg, feat_names, out_root=OUT_ROOT):
    """
    For a single CIF file:
      - Build graphlet from scratch
      - Compute histograms
      - Save split outputs
    """
    try:
        proc = ICSDGraphletProcessor(
            cif_file=cif_path,
            graphlet=None,
            bin_centers_clas_2d=bin_clas,
            bin_centers_reg_2d=bin_reg,
            feature_names=feat_names,
        )
        if not getattr(proc, "ok", False):
            err = getattr(proc, "error", None)
            if err is None:
                raise RuntimeError("ICSDGraphletProcessor init failed (no error object).")
            raise RuntimeError(f"{type(err).__name__}: {err}") from err

        hist_path, gpath = proc.pickle_split_outputs(out_root=out_root)
        return {"cif_path": cif_path, "graph_path": gpath, "hist_path": hist_path, "ok": True}

    except Exception as e:
        print(f"Failed for {cif_path}: {e}", flush=True)
        print(traceback.format_exc(limit=2), flush=True)
        return {"cif_path": cif_path, "error": str(e), "ok": False}


def _chunked(items, chunk_size):
    for i in range(0, len(items), chunk_size):
        yield items[i : i + chunk_size]


def _fmt_s(seconds: float) -> str:
    seconds = max(0.0, float(seconds))
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = seconds % 60
    if h > 0:
        return f"{h}h {m}m {s:.1f}s"
    if m > 0:
        return f"{m}m {s:.1f}s"
    return f"{s:.1f}s"


def _count_ok(results):
    ok = 0
    for r in results:
        if isinstance(r, dict) and bool(r.get("ok", False)):
            ok += 1
    return ok


def main():
    start_wall = time.strftime("%Y-%m-%d %H:%M:%S")
    start_t = time.time()

    bin_clas, bin_reg, feat_names = load_bins_from_config()

    os.makedirs(os.path.join(OUT_ROOT, "Histogram_Features"), exist_ok=True)
    os.makedirs(os.path.join(OUT_ROOT, "Graphlet_Data"), exist_ok=True)

    items_to_process = []
    process_func = None

    if MODE == "PICKLE":
        print(f"Mode: PICKLE (Regenerating from existing graphlets in {GRAPHLET_DIR})", flush=True)
        if not os.path.exists(GRAPHLET_DIR):
            print(f"Error: Graphlet directory not found: {GRAPHLET_DIR}", flush=True)
            return
        items_to_process = [
            os.path.join(GRAPHLET_DIR, f)
            for f in os.listdir(GRAPHLET_DIR)
            if f.endswith("_histogram.pkl")
        ]
        process_func = BuildFromGraphlet

    elif MODE == "CIF":
        print(f"Mode: CIF (Generating from scratch from CIFs in {CIF_DIR})", flush=True)
        if not os.path.exists(CIF_DIR):
            print(f"Error: CIF directory not found: {CIF_DIR}", flush=True)
            return
        items_to_process = [
            os.path.join(CIF_DIR, f)
            for f in os.listdir(CIF_DIR)
            if f.endswith(".cif")
        ]
        process_func = BuildFromCIF

    else:
        print(f"Error: Unknown MODE '{MODE}'. Use 'PICKLE' or 'CIF'.", flush=True)
        return

    total = len(items_to_process)
    print(f"Found {total} files to process.", flush=True)

    max_w = min(24, total or 1, os.cpu_count() or 24)
    chunk_size = int(os.getenv("FEATURE_MAKER_CHUNK_SIZE", "50"))
    chunk_size = max(1, chunk_size)
    n_chunks = math.ceil(total / chunk_size) if total else 0

    print(
        f"Feature_Maker settings: workers={max_w}, chunk_size={chunk_size}, chunks={n_chunks}",
        flush=True,
    )

    runner = ParallelRunner(executor="auto", max_workers=max_w, per_item_timeout_secs=3600)

    results = []
    done = 0
    ok_total = 0

    if total == 0:
        print("No files to process.", flush=True)
    else:
        for chunk_idx, chunk in enumerate(_chunked(items_to_process, chunk_size), start=1):
            chunk_t0 = time.time()
            chunk_results = runner.run(
                process_func,
                chunk,
                broadcast_kwargs={
                    "bin_clas": bin_clas,
                    "bin_reg": bin_reg,
                    "feat_names": feat_names,
                    "out_root": OUT_ROOT,
                },
                silent=True,
            )
            chunk_dt = time.time() - chunk_t0

            chunk_ok = _count_ok(chunk_results)
            results.extend(chunk_results)
            done += len(chunk_results)
            ok_total += chunk_ok
            fail_total = done - ok_total

            elapsed = time.time() - start_t
            rate = done / elapsed if elapsed > 0 else 0.0
            eta = (total - done) / rate if rate > 0 else float("inf")
            pct = 100.0 * done / total

            print(
                (
                    f"[progress] {done}/{total} ({pct:.1f}%) | "
                    f"chunk {chunk_idx}/{n_chunks} | "
                    f"chunk_ok={chunk_ok}/{len(chunk_results)} | "
                    f"ok={ok_total} fail={fail_total} | "
                    f"chunk_time={_fmt_s(chunk_dt)} | "
                    f"elapsed={_fmt_s(elapsed)} | "
                    f"eta={_fmt_s(eta) if math.isfinite(eta) else 'N/A'}"
                ),
                flush=True,
            )

    # --- Save manifest ---
    manifest_path = os.path.join(OUT_ROOT, f"manifest_{MODE.lower()}.pkl")
    with open(manifest_path, "wb") as f:
        pickle.dump(results, f, protocol=pickle.HIGHEST_PROTOCOL)

    # --- Save conversion report ---
    elapsed_s = time.time() - start_t
    success_count = _count_ok(results)
    failure_count = len(results) - success_count
    throughput = (len(results) / elapsed_s) if elapsed_s > 0 else 0.0

    report = {
        "mode": MODE,
        "started_at": start_wall,
        "finished_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "elapsed_seconds": elapsed_s,
        "elapsed_human": _fmt_s(elapsed_s),
        "total_files": len(results),
        "success_count": success_count,
        "failure_count": failure_count,
        "throughput_files_per_second": throughput,
        "workers": max_w,
        "chunk_size": chunk_size,
        "n_chunks": n_chunks,
        "cif_dir": CIF_DIR,
        "graphlet_dir": GRAPHLET_DIR,
        "out_root": OUT_ROOT,
        "manifest_path": manifest_path,
    }

    report_path = os.path.join(OUT_ROOT, f"conversion_report_{MODE.lower()}.json")
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)

    print(f"\nManifest written to: {manifest_path}", flush=True)
    print(f"Conversion report written to: {report_path}", flush=True)
    print(
        (
            f"Conversion summary: total={report['total_files']} "
            f"ok={report['success_count']} fail={report['failure_count']} "
            f"elapsed={report['elapsed_human']} "
            f"throughput={report['throughput_files_per_second']:.2f} files/s"
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
