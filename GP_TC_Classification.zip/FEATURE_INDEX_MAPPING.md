# Feature Index Mapping

This document provides the mapping between feature indices and their physical properties used in the graphlet representation.

## Graphlet Features (67 total)

| Index | Feature Name | Description |
|-------|--------------|-------------|
| 0 | `Pauling_EN_1_ord` | Pauling electronegativity (1st order, single atom) |
| 1 | `EA_1_ord` | Electron affinity (1st order, single atom) |
| 2 | `IP_1_ord` | Ionization potential (1st order, single atom) |
| 3 | `R_cov_1_ord` | Covalent radius (1st order, single atom) |
| 4 | `AtomicWeight_1_ord` | Atomic weight (1st order, single atom) |
| 5 | `NsValence_1_ord` | Number of s-valence electrons (1st order, single atom) |
| 6 | `NpValence_1_ord` | Number of p-valence electrons (1st order, single atom) |
| 7 | `NdValence_1_ord` | Number of d-valence electrons (1st order, single atom) |
| 8 | `Column_1_ord` | Periodic table column (1st order, single atom) |
| 9 | `NValence_1_ord` | Total valence electrons (1st order, single atom) |
| 10 | `Pauling_EN_mean_2_ord` | Pauling electronegativity mean (2nd order, bonded pair) |
| 11 | `Pauling_EN_abs_2_ord` | Pauling electronegativity absolute difference (2nd order, bonded pair) |
| 12 | `EA_mean_2_ord` | Electron affinity mean (2nd order, bonded pair) |
| 13 | `EA_abs_2_ord` | Electron affinity absolute difference (2nd order, bonded pair) |
| 14 | `IP_mean_2_ord` | Ionization potential mean (2nd order, bonded pair) |
| 15 | `IP_abs_2_ord` | Ionization potential absolute difference (2nd order, bonded pair) |
| 16 | `R_cov_mean_2_ord` | Covalent radius mean (2nd order, bonded pair) |
| 17 | `R_cov_abs_2_ord` | Covalent radius absolute difference (2nd order, bonded pair) |
| 18 | `AtomicWeight_mean_2_ord` | Atomic weight mean (2nd order, bonded pair) |
| 19 | `AtomicWeight_abs_2_ord` | Atomic weight absolute difference (2nd order, bonded pair) |
| 20 | `NsValence_mean_2_ord` | s-valence electrons mean (2nd order, bonded pair) |
| 21 | `NsValence_abs_2_ord` | s-valence electrons absolute difference (2nd order, bonded pair) |
| 22 | `NpValence_mean_2_ord` | p-valence electrons mean (2nd order, bonded pair) |
| 23 | `NpValence_abs_2_ord` | p-valence electrons absolute difference (2nd order, bonded pair) |
| 24 | `NdValence_mean_2_ord` | d-valence electrons mean (2nd order, bonded pair) |
| 25 | `NdValence_abs_2_ord` | d-valence electrons absolute difference (2nd order, bonded pair) |
| 26 | `Column_mean_2_ord` | Periodic table column mean (2nd order, bonded pair) |
| 27 | `Column_abs_2_ord` | Periodic table column absolute difference (2nd order, bonded pair) |
| 28 | `NValence_mean_2_ord` | Total valence electrons mean (2nd order, bonded pair) |
| 29 | `NValence_abs_2_ord` | Total valence electrons absolute difference (2nd order, bonded pair) |
| 30 | `bond_len_2_ord` | Bond length (2nd order, bonded pair) |
| 31 | `Pauling_EN_mean_3_ord` | Pauling electronegativity mean (3rd order, triplet) |
| 32 | `Pauling_EN_std_3_ord` | Pauling electronegativity standard deviation (3rd order, triplet) |
| 33 | `Pauling_EN_kurt_3_ord` | Pauling electronegativity kurtosis (3rd order, triplet) |
| 34 | `EA_mean_3_ord` | Electron affinity mean (3rd order, triplet) |
| 35 | `EA_std_3_ord` | Electron affinity standard deviation (3rd order, triplet) |
| 36 | `EA_kurt_3_ord` | Electron affinity kurtosis (3rd order, triplet) |
| 37 | `IP_mean_3_ord` | Ionization potential mean (3rd order, triplet) |
| 38 | `IP_std_3_ord` | Ionization potential standard deviation (3rd order, triplet) |
| 39 | `IP_kurt_3_ord` | Ionization potential kurtosis (3rd order, triplet) |
| 40 | `R_cov_mean_3_ord` | Covalent radius mean (3rd order, triplet) |
| 41 | `R_cov_std_3_ord` | Covalent radius standard deviation (3rd order, triplet) |
| 42 | `R_cov_kurt_3_ord` | Covalent radius kurtosis (3rd order, triplet) |
| 43 | `AtomicWeight_mean_3_ord` | Atomic weight mean (3rd order, triplet) |
| 44 | `AtomicWeight_std_3_ord` | Atomic weight standard deviation (3rd order, triplet) |
| 45 | `AtomicWeight_kurt_3_ord` | Atomic weight kurtosis (3rd order, triplet) |
| 46 | `NsValence_mean_3_ord` | s-valence electrons mean (3rd order, triplet) |
| 47 | `NsValence_std_3_ord` | s-valence electrons standard deviation (3rd order, triplet) |
| 48 | `NsValence_kurt_3_ord` | s-valence electrons kurtosis (3rd order, triplet) |
| 49 | `NpValence_mean_3_ord` | p-valence electrons mean (3rd order, triplet) |
| 50 | `NpValence_std_3_ord` | p-valence electrons standard deviation (3rd order, triplet) |
| 51 | `NpValence_kurt_3_ord` | p-valence electrons kurtosis (3rd order, triplet) |
| 52 | `NdValence_mean_3_ord` | d-valence electrons mean (3rd order, triplet) |
| 53 | `NdValence_std_3_ord` | d-valence electrons standard deviation (3rd order, triplet) |
| 54 | `NdValence_kurt_3_ord` | d-valence electrons kurtosis (3rd order, triplet) |
| 55 | `Column_mean_3_ord` | Periodic table column mean (3rd order, triplet) |
| 56 | `Column_std_3_ord` | Periodic table column standard deviation (3rd order, triplet) |
| 57 | `Column_kurt_3_ord` | Periodic table column kurtosis (3rd order, triplet) |
| 58 | `NValence_mean_3_ord` | Total valence electrons mean (3rd order, triplet) |
| 59 | `NValence_std_3_ord` | Total valence electrons standard deviation (3rd order, triplet) |
| 60 | `NValence_kurt_3_ord` | Total valence electrons kurtosis (3rd order, triplet) |
| 61 | `bond_len_mean_3_ord` | Bond length mean (3rd order, triplet) |
| 62 | `bond_len_std_3_ord` | Bond length standard deviation (3rd order, triplet) |
| 63 | `bond_len_kurt_3_ord` | Bond length kurtosis (3rd order, triplet) |
| 64 | `angle_mean_3_ord` | Bond angle mean (3rd order, triplet) |
| 65 | `angle_std_3_ord` | Bond angle standard deviation (3rd order, triplet) |
| 66 | `angle_kurt_3_ord` | Bond angle kurtosis (3rd order, triplet) |

## Symmetry Features (11 total)

| Index | Feature Name | Description |
|-------|--------------|-------------|
| 0 | `i` | Inversion symmetry (center of inversion) |
| 1 | `mv` | Vertical mirror plane (σv) |
| 2 | `mh` | Horizontal mirror plane (σh) |
| 3 | `md` | Diagonal/dihedral mirror plane (σd) |
| 4 | `C2` | 2-fold rotation axis (180° rotation) |
| 5 | `C3` | 3-fold rotation axis (120° rotation) |
| 6 | `C4` | 4-fold rotation axis (90° rotation) |
| 7 | `C6` | 6-fold rotation axis (60° rotation) |
| 8 | `-3` | 3-fold rotoinversion (S6, improper rotation) |
| 9 | `-4` | 4-fold rotoinversion (S4, improper rotation) |
| 10 | `-6` | 6-fold rotoinversion (S3, improper rotation) |

## Feature Order Terminology

- **1st order**: Properties of individual atoms (nodes in the crystal graph)
- **2nd order**: Properties of bonded atom pairs (edges in the crystal graph)
- **3rd order**: Properties of atom triplets forming angles (triangles in the crystal graph)

## Statistical Descriptors

- **mean**: Average value across all graphlets
- **abs**: Absolute difference between bonded atoms
- **std**: Standard deviation across triplet atoms
- **kurt**: Kurtosis (measure of distribution "tailedness") across triplet atoms
